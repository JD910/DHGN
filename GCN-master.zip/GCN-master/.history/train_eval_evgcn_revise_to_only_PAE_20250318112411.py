import os
import sys
import torch
import torch_geometric.datasets as GeoData
from torch_geometric.data import DataLoader, DataListLoader
from torch_geometric.nn.data_parallel import DataParallel
import random
import numpy as np
import xlrd
import pandas as pd
import datetime
 

from opt import * 
from EV_GCN_PAE import EV_GCN
from utils.metrics_PAE import accuracy, auc, prf
from dataloader_PAE import dataloader 
from PAE import PAE


def dataset_create(data_excel):
    data_all = pd.read_excel(data_excel, sheet_name='PFS1007')#读取所有data
    
    length = data_all.shape[1]
    
    data_feat = data_all.iloc[[4,10,12,18,24,29,48,56,76], 1:]
    #data_feat = data_all.iloc[[4,12,18,29,31,76], 1:]
    data_feat.columns = data_feat.iloc[0]  # 将第一行作为列名
    data_feat = data_feat[1:].reset_index(drop=True)  # 删除第一行并重置索引

    #YDYY_Index = data_feat.columns[data_feat.columns.str.contains('YDYY', case=False)]
    YDYY_Index = data_feat.columns[data_feat.columns.str.contains('SJ' or "NFYY", case=False)]
    
    MSK_Index = data_feat.columns[data_feat.columns.str.contains('MSK', case=False)]
    
    data_feat_test_YDYY = data_feat[YDYY_Index]
    data_feat_test_MSK =  data_feat[MSK_Index]

    # 获取 A 的所有列名
    all_columns = data_feat.columns
    # 获取 B 和 C 的列名
    b_columns = data_feat_test_YDYY.columns
    c_columns = data_feat_test_MSK.columns
    # 排除 B 和 C 的列名，得到剩余的列名
    remaining_columns = all_columns.difference(b_columns.union(c_columns))
    # 用剩余的列名从 A 中提取数据，生成新的 DataFrame
    data_feat_train = data_feat[remaining_columns]
    
    data_feat_train_numpy = data_feat_train.to_numpy()
    data_feat_train_numpy =  np.transpose(data_feat_train_numpy).astype('float32')
    nonimg_train = data_feat_train_numpy
    
    data_feat_test_YDYY_numpy = data_feat_test_YDYY.to_numpy()
    data_feat_test_YDYY_numpy =  np.transpose(data_feat_test_YDYY_numpy).astype('float32')
    nonimg_YDYY = data_feat_test_YDYY_numpy
    
    data_feat_test_MSK_numpy = data_feat_test_MSK.to_numpy()
    data_feat_test_MSK_numpy =  np.transpose(data_feat_test_MSK_numpy).astype('float32')
    nonimg_MSK = data_feat_test_MSK_numpy
    
    data_feat.columns = data_feat.iloc[0]  # 将第一行作为列名
    data_feat = data_feat[1:].reset_index(drop=True)  # 删除第一行并重置索引
    data_pfs = data_all.iloc[61:62, 1:]
    
    data_pfs = data_all.iloc[[4,61], 1:]
    data_pfs.columns = data_pfs.iloc[0]  # 将第一行作为列名
    data_pfs = data_pfs[1:].reset_index(drop=True)  # 删除第一行并重置索引
    
    data_pfs_lab_YDYY = data_pfs[YDYY_Index]
    data_pfs_lab_MSK = data_pfs[MSK_Index]
    data_pfs_lab_train = data_pfs[remaining_columns]
    data_pfs_lab_YDYY = data_pfs_lab_YDYY.to_numpy().squeeze().astype('float32')
    data_pfs_lab_MSK = data_pfs_lab_MSK.to_numpy().squeeze().astype('float32')
    data_pfs_lab_train = data_pfs_lab_train.to_numpy().squeeze().astype('float32')
    
    return data_pfs_lab_YDYY, data_pfs_lab_MSK, data_pfs_lab_train, nonimg_YDYY, nonimg_MSK, nonimg_train
    

if __name__ == '__main__':
    opt = OptInit().initialize()

    print('  Loading dataset ...')
    dl = dataloader() 
    raw_features, y, nonimg = dl.load_data()

    n_folds = 10
    cv_splits = dl.data_split(n_folds)

    corrects = np.zeros(n_folds, dtype=np.int32) 
    accs = np.zeros(n_folds, dtype=np.float32) 
    aucs = np.zeros(n_folds, dtype=np.float32)
    prfs = np.zeros([n_folds,3], dtype=np.float32)

    PFS_YDYY, PFS_MSK, PFS_train, nonimg_YDYY, nonimg_MSK, nonimg_train = dataset_create("/home/ewer/Data8T/2024ICI/Excel/ICI_All250316_GCN.xlsx")



    print('  Constructing graph data...')
    # extract node features  
    #node_ftr = dl.get_node_features(train_ind)
    # get PAE inputs
    edge_label, edge_index, edgenet_input = dl.get_PAE_inputs(nonimg_train, PFS_train) 
    # normalization for PAE
    edgenet_input = (edgenet_input - edgenet_input.mean(axis=0)) / edgenet_input.std(axis=0)
    
    edge_label_test_MSK, edge_index_test_MSK, edgenet_input_test_MSK = dl.get_PAE_inputs(nonimg_MSK, PFS_MSK) 
    # normalization for PAE
    edgenet_input_test_MSK = (edgenet_input_test_MSK - edgenet_input_test_MSK.mean(axis=0)) / edgenet_input_test_MSK.std(axis=0)
    
    edge_label_test_YDYY, edge_index_test_YDYY, edgenet_input_test_YDYY = dl.get_PAE_inputs(nonimg_YDYY, PFS_YDYY) 
    # normalization for PAE
    edgenet_input_test_YDYY = (edgenet_input_test_YDYY - edgenet_input_test_YDYY.mean(axis=0)) / edgenet_input_test_YDYY.std(axis=0)
    
    # build network architecture  
    
    model = EV_GCN(opt.dropout, edge_dropout=opt.edropout, edgenet_input_dim=2*nonimg_train.shape[1]).to(opt.device)
    model = model.to(opt.device)

    # build loss, optimizer, metric 
    #loss_fn =torch.nn.CrossEntropyLoss()
    loss_fn =torch.nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=opt.lr, weight_decay=opt.wd)
    #features_cuda = torch.tensor(node_ftr, dtype=torch.float32).to(opt.device)
    edge_index = torch.tensor(edge_index, dtype=torch.long).to(opt.device)
    edgenet_input = torch.tensor(edgenet_input, dtype=torch.float32).to(opt.device)
    #labels = torch.tensor(y, dtype=torch.long).to(opt.device)
    labels = torch.tensor(edge_label, dtype=torch.float32).to(opt.device)
    now = datetime.datetime.now()
    fold_model_path = opt.ckpt_path + "/{}.pth".format(now)
    
    print("  Number of training samples %d" % len(PFS_train))
    print("  Start training...\r\n")
    acc = 0

    
    opt.train = 0
    fold_model_path = './save_models/ev_gcn/2025-03-18 11:16:32.457128.pth'
    
    if opt.train==1:
        for epoch in range(opt.num_iter):
            model.train()  
            optimizer.zero_grad()
            with torch.set_grad_enabled(True):
                edge_weights = model(edge_index, edgenet_input)
                #loss = loss_fn(node_logits[train_ind], labels[train_ind])
                loss = loss_fn(edge_weights, labels)
                loss.backward()
                optimizer.step()
                print("Epoch: {},\tce loss: {:.5f}".format(epoch, loss.item()))
                edge_weights_pred_labels = torch.where(edge_weights > 0.55, 1, 0)
            correct_train, acc_train = accuracy(edge_weights_pred_labels.detach().cpu().numpy(), labels.detach().cpu().numpy())
            
            model.eval()
            with torch.set_grad_enabled(False):
                edge_weights_test = model(edge_index, edgenet_input)
            edge_weights_test_pred_labels = torch.where(edge_weights_test > 0.5, 1, 0)
            edge_weights_test_pred_labels = edge_weights_test_pred_labels.detach().cpu().numpy()
            correct_test, acc_test = accuracy(edge_weights_test_pred_labels, labels.detach().cpu().numpy())
            #auc_test = auc(logits_test,y[test_ind])
            #prf_test = prf(logits_test,y[test_ind])

            if acc_test > acc and epoch >9:
                print(acc_test)
                acc = acc_test
                correct = correct_test 
                #aucs[fold] = auc_test
                #prfs[fold]  = prf_test  
                if opt.ckpt_path !='':
                    if not os.path.exists(opt.ckpt_path): 
                        #print("Checkpoint Directory does not exist! Making directory {}".format(opt.ckpt_path))
                        os.makedirs(opt.ckpt_path)
                    torch.save(model.state_dict(), fold_model_path)
        
        opt.train = 0        
                    
        
                    
    
    if opt.train==0:
        print('  Start testing...')
        model.load_state_dict(torch.load(fold_model_path)) 
        model.eval()
        
        edge_index = torch.tensor(edge_index, dtype=torch.long).to(opt.device)
        edgenet_input = torch.tensor(edgenet_input, dtype=torch.float32).to(opt.device)
        #labels = torch.tensor(y, dtype=torch.long).to(opt.device)
        labels = torch.tensor(edge_label, dtype=torch.float32).to(opt.device)
        
        edge_index_test_MSK = torch.tensor(edge_index_test_MSK, dtype=torch.long).to(opt.device)
        edgenet_input_test_MSK = torch.tensor(edgenet_input_test_MSK, dtype=torch.float32).to(opt.device)
        #labels = torch.tensor(y, dtype=torch.long).to(opt.device)
        labels_test_MSK = torch.tensor(edge_label_test_MSK, dtype=torch.float32).to(opt.device)
        
        edge_index_test_YDYY = torch.tensor(edge_index_test_YDYY, dtype=torch.long).to(opt.device)
        edgenet_input_test_YDYY = torch.tensor(edgenet_input_test_YDYY, dtype=torch.float32).to(opt.device)
        #labels = torch.tensor(y, dtype=torch.long).to(opt.device)
        labels_test_YDYY = torch.tensor(edge_label_test_YDYY, dtype=torch.float32).to(opt.device)
        
        edge_weights = model(edge_index, edgenet_input)
        edge_weights_train_pred_labels = torch.where(edge_weights > 0.54, 1, 0)
        edge_weights_train_pred_labels = edge_weights_train_pred_labels.detach().cpu().numpy()
        correct_train, acc_train = accuracy(edge_weights_train_pred_labels, labels.detach().cpu().numpy())
        aucs_train = auc(edge_weights_train_pred_labels,labels.detach().cpu().numpy()) 
        prfs_train  = prf(edge_weights_train_pred_labels,labels.detach().cpu().numpy())  
        
        edge_weights_test_MSK = model(edge_index_test_MSK, edgenet_input_test_MSK)
        edge_weights_test_MSK_pred_labels = torch.where(edge_weights_test_MSK > 0.353, 1, 0)
        edge_weights_test_MSK_pred_labels = edge_weights_test_MSK_pred_labels.detach().cpu().numpy()
        correct_test_MSK, acc_test_MSK = accuracy(edge_weights_test_MSK_pred_labels, labels_test_MSK.detach().cpu().numpy())
        aucs_test_MSK = auc(edge_weights_test_MSK_pred_labels,labels_test_MSK.detach().cpu().numpy()) 
        prfs_test_MSK  = prf(edge_weights_test_MSK_pred_labels,labels_test_MSK.detach().cpu().numpy())  


        edge_weights_test_YDYY = model(edge_index_test_YDYY, edgenet_input_test_YDYY)
        edge_weights_test_YDYY_pred_labels = torch.where(edge_weights_test_YDYY > 0.48, 1, 0)
        edge_weights_test_YDYY_pred_labels = edge_weights_test_YDYY_pred_labels.detach().cpu().numpy()
        correct_test_YDYY, acc_test_YDYY = accuracy(edge_weights_test_YDYY_pred_labels, labels_test_YDYY.detach().cpu().numpy())
        aucs_test_YDYY = auc(edge_weights_test_YDYY_pred_labels,labels_test_YDYY.detach().cpu().numpy()) 
        prfs_YDYY  = prf(edge_weights_test_YDYY_pred_labels,labels_test_YDYY.detach().cpu().numpy())
        
        i = 0.1
        while i < 1:
            edge_weights_test_YDYY = model(edge_index_test_YDYY, edgenet_input_test_YDYY)
            edge_weights_test_YDYY_pred_labels = torch.where(edge_weights_test_YDYY > i, 1, 0)
            edge_weights_test_YDYY_pred_labels = edge_weights_test_YDYY_pred_labels.detach().cpu().numpy()
            correct_test_YDYY, acc_test_YDYY = accuracy(edge_weights_test_YDYY_pred_labels, labels_test_YDYY.detach().cpu().numpy())
            aucs_test_YDYY = auc(edge_weights_test_YDYY_pred_labels,labels_test_YDYY.detach().cpu().numpy()) 
            prfs_YDYY  = prf(edge_weights_test_YDYY_pred_labels,labels_test_YDYY.detach().cpu().numpy())
            se, sp, f1 = prfs_YDYY
            if((acc_test_YDYY > 0.65) and (f1 > 0.65)):
                print("=> Average test YDYY in i  {:.4f} with sensitivity {:.4f}, specificity {:.4f}, F1-score {:.4f}".format(se, sp, f1))
                break
            else:
                i = i + 0.001
                
        #print("  Test accuracy {:.5f}, AUC {:.5f}".format(acc_test_MSK, acc_test_YDYY))
        
        # n = nonimg_MSK.shape[0]
        # flatten_ind = 0
        # edge_list_test = []              
        # for i in range(n):
        #     for j in range(i+1, n):
        #         if(edge_weights_test[flatten_ind] > 0.5):
        #             edge_list_test.append((i,j))
        #         flatten_ind +=1

    ##print("\r\n========================== Finish ==========================") 

    print("=> Average test accuracy: {:.5f}, {:.5f}, {:.5f}".format(acc_train, acc_test_MSK, acc_test_YDYY))
    #print("=> Average test AUC: {:.5f}, {:.5f}, {:.5f}".format(np.mean(aucs_train),np.mean(aucs_test_MSK),np.mean(aucs_test_YDYY)))
    
    #se, sp, f1 = np.mean(prfs_test_MSK,axis=0)
    se, sp, f1 = prfs_train
    print("=> Average train sensitivity {:.4f}, specificity {:.4f}, F1-score {:.4f}".format(se, sp, f1))
    
    #se, sp, f1 = np.mean(prfs_test_MSK,axis=0)
    se, sp, f1 = prfs_test_MSK
    print("=> Average test MSK sensitivity {:.4f}, specificity {:.4f}, F1-score {:.4f}".format(se, sp, f1))
    
    #se, sp, f1 = np.mean(prfs_YDYY,axis=0)
    se, sp, f1 = prfs_YDYY
    print("=> Average test YDYY sensitivity {:.4f}, specificity {:.4f}, F1-score {:.4f}".format(se, sp, f1))

